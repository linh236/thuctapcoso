﻿#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cstringt.h>
#include <stdio.h>
#include <iomanip>
#include <fcntl.h>
#include <io.h>
#include <windows.h>
#include <codecvt>
#include <vector>
#include <locale>
#include<stdlib.h> 
#include <conio.h>
#include <algorithm>
#include<stdlib.h>
#include "bgi/graphics.h"
using namespace std;
// khai báo struct SINHVIEN
struct SINHVIEN
{	
	wstring MASV;
	wstring hoten;
	wstring CMND;
	wstring quequan;
	wstring email;
	wstring chohientai;
	wstring date;
};
void menu();
void back();
void xoasvtrung(vector<SINHVIEN>& sv);
wstring tach_nam(wstring date);
// set tieng viet dư vào trong file
void set_tieng_viet(wofstream &f) {
	locale loc(locale(), new codecvt_utf8<wchar_t>);// đọc và ghi văn bản 
	f.imbue(loc);
}
// Hiển thị thông tin sinh viên ra màn hình
void Hien_thi(SINHVIEN sv) {
	wcout <<L"|"<< setw(20) << sv.MASV << setw(5) << L"|" << setw(20) << sv.hoten << setw(5) << L"|" << setw(15) << sv.CMND << setw(5) << L"|" << setw(15) << sv.date << setw(5) << L"|" << setw(15) << sv.quequan << setw(5) << L"|" << setw(20) << sv.email << setw(5) << L"|" << setw(20) << sv.chohientai << setw(10) << L"|" << endl;
}
// ghi vào trong file
void ghi_vao_file(SINHVIEN sv, wofstream& file) {
	set_tieng_viet(file);
	file <<sv.MASV << L"," << sv.hoten << L"," << sv.CMND << L"," << sv.date << L"," << sv.quequan << L"," << sv.email << L"," << sv.chohientai << L"\n";
}
// kiểm tra sinh viên có masv trong lúc thêm sinh viên có bị trùng hay không ?
int kiemtra_sv_masv(vector <SINHVIEN> sv, wstring masv) {
	int flag = 0;
	for (int i = 1; i < sv.size(); i++) {
		if (masv == sv[i].MASV) {
			wcout << L"Sinh viên có mã "<< masv << L" đã tồn tại trong danh sách.\n";
			flag = 1;
		}
	}
	return flag;
}
// kiểm tra sinh viên có cmnd trong lúc thêm sinh viên có bị trùng hay không ?
int kiemtra_sv_cmnd(vector <SINHVIEN> sv, wstring cmnd) {
	int flag = 0;
	for (int i = 1; i < sv.size(); i++) {
		if (cmnd == sv[i].CMND) {
			wcout << L"Sinh viên có CMND " << cmnd << L" đã tồn tại trong danh sách.\n";
			flag = 1;
		}
	}
	return flag;
}
// câu 1 đọc dữ liệu từ file 
void Doc_tu_file_sinhvien(wifstream &file, SINHVIEN &sv) {
		locale loc(locale(), new codecvt_utf8<wchar_t>);
		file.imbue(loc);
		getline(file, sv.MASV, L',');
		getline(file, sv.hoten, L',');
		getline(file, sv.CMND, L',');
		getline(file, sv.date, L',');
		getline(file, sv.quequan, L',');
		getline(file, sv.email, L',');
		getline(file, sv.chohientai);
}
// Đọc danh sách sinh viên cho vào vector SINHVIEN
void Doc_danh_sach_sinh_vien(wifstream &file, vector<SINHVIEN> &danh_sach_sv) {
	if (!file.is_open()) {
		wcout << L"LỖI MỞ FILE !\n";
	}
	while (file.good()) {
		SINHVIEN sv; // khai báo danh sách sinh viên để nhận dữ liệu về
		Doc_tu_file_sinhvien(file, sv);
		danh_sach_sv.push_back(sv);

	}
}
// Đọc dữ liệu từ vector SINHVIEN rồi hiển thị ra màn hình
void Xuat_danh_sach_sinh_vien(vector<SINHVIEN> ds) {
	wcout << "======================================================================================================================================================================\n";
	wcout << L"|                                                                         DANH SÁCH SINH VIÊN                                                                        |\n";
	wcout << "======================================================================================================================================================================\n";
	for (int i = 0; i < ds.size()-1; i++) {
		Hien_thi(ds[i]);
	}
	wcout << "======================================================================================================================================================================\n";

}
/*
2/ Sử dụng Merge sort để sắp xếp các sinh viên theo thứ tự với tiêu chí sắp xếp sẽ được nhập vào.
	Ví dụ: tiêu chí: ngày tháng năm sinh, MSSV hay số CMND

*/
int kiemtra_ngay(wstring& date,wstring &date1) {
	for (int i = 0; i < date.size(); i ++) {
		if (date[i] >= 0 && date[i] <= 9) {
			if (date1[i] >= 0 && date1[i] <= 9) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
			
	}
}
int sosanh_ngaysinh(wstring &date, wstring &date1) {
	wstring ngay;
	wstring thang;
	vector <int> tam;
	wstring ngay1;
	wstring thang1;
	vector <int> tam1;
	wstring nam = tach_nam(date);
	wstring nam1 = tach_nam(date1);

	int flag = 0;
	for (int i = 0; i < date.size(); i++) {
		if (date[i] == L'/') {
			tam.push_back(i);
		}
	}
	for (int i = 0; i < date.size(); i++) {
		ngay = date.substr(0, tam[0]);
		thang = date.substr(tam[0] + 1, tam.size() - 1);
	}
	for (int i = 0; i < date1.size(); i++) {
		if (date1[i] == L'/') {
			tam1.push_back(i);
		}
	}
	for (int i = 0; i < date1.size(); i++) {
		ngay1 = date1.substr(0, tam1[0]);
		thang1 = date1.substr(tam1[0] + 1, tam1.size() - 1);
	}
	if (nam.compare(nam1) == 0) {
		if (thang.compare(thang1) == 0) {
			if (ngay.compare(ngay1) == 0) {
				return 0;
			}
			else {
				if (ngay > ngay1) {
					return 1;
				}
				else return -1;
			}
		}
		else {
			if (thang > thang1) return 1;
			else return -1;
		}
	}
	else {
		if (nam > nam1) return 1;
		else return -1;
	}
}
void Merge(vector<SINHVIEN>& L, vector<SINHVIEN>& R, vector<SINHVIEN>& ds, wstring luachon) {
	int nL = L.size();
	int nR = R.size();
	int i = 0, j = 0, k = 0;
	while (j < nL && k < nR)
	{
	
		if (luachon == L"a"||luachon==L"A") {
			if (L[0].date == L"NGÀY SINH") {
				j++; k++;

				break;
			}
				if (sosanh_ngaysinh(L[j].date, R[k].date) <= 0)
				{
					ds[i] = L[j];
					j++;
				}
				else
				{
					ds[i] = R[k];
					k++;
				}
				i++;
			}

		if (luachon == L"b"|| luachon ==L"B") {
			if (L[0].date == L"MASV") {
				j++; k++;

				break;
			}
			if (L[j].MASV < R[k].MASV)
			{
				ds[i] = L[j];
				j++;
			}
			else
			{
				ds[i] = R[k];
				k++;
			}
			i++;
		}
		if (luachon == L"c"||luachon==L"C") {
			if (L[0].date == L"SỐ CMND") {
				j++; k++;

				break;
			}
			if (L[j].CMND < R[k].CMND)
			{
				ds[i] = L[j];
				j++;
			}
			else
			{
				ds[i] = R[k];
				k++;
			}
			i++;
		}
		
	}
	while (j < nL)
	{
		ds[i] = L[j];
		j++; i++;
	}
	while (k < nR)
	{
		ds[i] = R[k];
		k++; i++;
	}
}
void mergeSort(vector<SINHVIEN>& ds, wstring luachon) {
	if (ds.size() <= 1) return;
	int mid = ds.size() / 2;
	vector<SINHVIEN>L;
	vector<SINHVIEN>R;
	
	for (size_t i = 0; i < mid; i++) {
		L.push_back(ds[i]);
	}

	for (size_t i = 0; i < (ds.size()) - mid; i++) {
		R.push_back(ds[mid + i]);
	}
	
	mergeSort(L, luachon);
	mergeSort(R, luachon);
	Merge(L, R, ds, luachon);
}
void sapXepSV(vector<SINHVIEN>& ds, wstring luachon) {
	//wcout << L"|" << setw(20) <<L"MASV" << setw(5) << L"|" << setw(20) << L"HỌ VÀ TÊN" << setw(5) << L"|" << setw(15) << L"SỐ CMND" << setw(5) << L"|" << setw(15) << L"NGÀY SINH" << setw(5) << L"|" << setw(15) << L"QUÊ QUÁN" << setw(5) << L"|" << setw(20) << L"EMAIL" << setw(5) << L"|" << setw(20) << L"CHỔ HIỆN TẠI" << setw(10) << L"|" << endl;

	for (int i = 1; i < ds.size(); i++) {
		mergeSort(ds, luachon);
		xoasvtrung(ds);
		Hien_thi(ds[i]);

	}
};
/*câu 3: Thêm 1 sinh viên vào danh sách*/
void themsinhvien(SINHVIEN& sv, vector <SINHVIEN> ds_sv) {
	//std::locale loc(std::locale(), new std::codecvt_utf8<wchar_t>);
	//outData.open(L"sinhvien.csv", ios::app);
	
	int ketqua;
	//for (int i = 0; i < n; i++) {
	wcout << L"THÊM SINH VIÊN \n";
	//fflush(stdin);
	do {
		wcout << L"NHẬP MASV :"; wcin >> sv.MASV;

	} while (kiemtra_sv_masv(ds_sv, sv.MASV) == 1);
	wcin.ignore();
	wcout << L"NHẬP HỌ VÀ TÊN :"; getline(wcin, sv.hoten);
	
	do {
		wcout << L"NHẬP CMND :"; wcin >> sv.CMND;
	} while (kiemtra_sv_cmnd(ds_sv, sv.CMND) == 1);
	wcout << L"NHẬP NGÀY/THÁNG/NĂM :"; wcin >> sv.date;
	wcin.ignore();
	wcout << L"NHẬP QUÊ QUÁN:"; getline(wcin, sv.quequan);
	wcout << L"NHẬP EMAIL :"; wcin >> sv.email;
	wcin.ignore();
	wcout << L"NHẬP CHỔ Ở HIỆN TẠI :"; getline(wcin, sv.chohientai, L'\n');
	
	//outData << sv.MASV << L","  << sv.hoten << L"," << sv.CMND << L"," << sv.d << L"/" << sv.m << L"/" << sv.y << L"," << sv.quequan << L"," << sv.email << L"," << sv.chohientai << endl;

//}

}
// đưa sinh viên vào tiêu chí thêm
void themtheotieuchi(SINHVIEN &s, wstring &chon, wofstream &outData,wifstream &filein, vector <SINHVIEN>&sv) {
	outData.open(L"sinhvien.csv");
	set_tieng_viet(outData);
	outData << L"MASV" << L"," << L"HỌ VÀ TÊN" << L"," << L"SỐ CMND" << L"," << L"NGÀY SINH" << L"," << L"QUÊ QUÁN" << L"," << L"EMAIL" << L"," << L"CHỔ HIỆN TẠI" << L"\n";

	if (chon == L"a"|| chon ==L"A") {
		themsinhvien(s,sv);
		sv.push_back(s);
		sapXepSV(sv, chon);
		wcout << L"Bấm Enter để hoàn tất thao tác thêm sinh viên.\n";
		for (int i = 1; i < sv.size() - 1; i++) {
			ghi_vao_file(sv[i], outData);
		}
	}
	if (chon == L"b" || chon == L"B") {
		themsinhvien(s, sv);
		sv.push_back(s);
		sapXepSV(sv, chon);
		wcout << L"Bấm Enter để hoàn tất thao tác thêm sinh viên.\n";
		for (int i = 1; i < sv.size()-1; i++) {
			ghi_vao_file(sv[i], outData);
		}

	}
	if (chon == L"c" || chon == L"C") {
		themsinhvien(s,sv);
		sv.push_back(s);
		sapXepSV(sv, chon);
		for (int i = 1; i < sv.size() - 1; i++) {
			ghi_vao_file(sv[i], outData);
		}

	}
	
	outData.close();

}
// cập nhật vào file
void capnhat_vaofile(wofstream &file, vector <SINHVIEN> &newsv) {
	for (int i = 0; i < newsv.size()-1; i++) {
		ghi_vao_file(newsv[i],file);
	}
}
/*câu 4: Xóa sinh viên trong danh sách*/
void xoa( vector <SINHVIEN> newsv, wofstream &fileout) {
	int chon;
	int luu;
	wcout << L"Bạn có muốn xóa không ?\n";
	wcout << L"\t1: xóa\n";
	wcout << L"\t0: hủy\n";
	wcout << L"Nhập lựa chọn :";
	wcin >> chon;
	if (chon == 1 ) {
		for (int i = 0; i < newsv.size()-1; i++) {
			Hien_thi(newsv[i]);
		}
		wcout << L"Bạn có muốn lưu ?\n";
		wcout << L"\t1: xóa\n";
		wcout << L"\t0: hủy\n";
		wcout << L"\tNhập lựa chọn :";
		wcin >> luu;
		if (luu == 1) {
			fileout.open(L"sinhvien.csv");
			capnhat_vaofile(fileout, newsv);
		}
		else {
			back();
		}
	}
	else {
		back();
	}
}
// tách họ tên ra lấy tên
wstring tach_hoten(wstring hoten) {
	vector <int > tam;
	int vitri;
	wstring ten;
	for (int i = 0; i < hoten.size(); i++) {
		if (hoten[i] == ' ') {
			tam.push_back(i);
		}
	}
	for (int i = 0; i < tam.size(); i++) {
		for (int j = i + 1; j < tam.size(); j++) {
			if (tam[i] < tam[j]) {
				vitri = tam[j];
				ten = hoten.substr(vitri + 1, hoten.size());
			}
		}
	}
	return ten;
}
// in hoa tên nhập vào và tên trong danh sách để so sánh.
wstring str_upper(wstring str) {
	transform(str.begin(), str.end(), str.begin(), ::toupper);
	return str;
}
// tìm kiếm theo tên từ trong họ tên
void timkiem_hoten(vector<SINHVIEN> sv,wofstream &file) {
	wstring key; int flag = 0;
	vector <SINHVIEN> newsv;
	SINHVIEN s;
	wcout << L"Nhập tên tìm kiếm :";
	wcin >> key;
	wcout << L"Kết quả tìm kiếm: "<< key<< endl;
	for (int i = 0; i < sv.size(); i++) {
		wstring ten = tach_hoten(sv[i].hoten);
		if (str_upper(ten).find(str_upper(key)) == 0) {
			//newsv.push_back(sv[i]);
			Hien_thi(sv[i]);
			flag = 1;
		}
	}
	if (flag == 1) {
		for (int i = 0; i < sv.size(); i++) {
			wstring ten = tach_hoten(sv[i].hoten);
			if (str_upper(ten).find(str_upper(key)) != 0) {
				newsv.push_back(sv[i]);
			}
		}
		xoa(newsv, file);
	}
	else {
		wcout << L"Không tìm thấy sinh viên có tên " << key << endl;
		Sleep(4000);
		back();
	}
}
// tách ngày/tháng/năm để lấy năm mang ra tìm kiếm.
wstring tach_nam(wstring date) {
	vector <int > tam;
	int vitri;
	wstring nam;
	for (int i = 0; i < date.size(); i++) {
		if (date[i] == '/') {
			tam.push_back(i);
		}
	}

	for (int i = 0; i < tam.size(); i++) {
		for (int j = i + 1; j < tam.size(); j++) {
			if (tam[i] < tam[j]) {
				vitri = tam[j];
				nam = date.substr(vitri + 1, date.size());
			}
		}
	}
	return nam;
}
// tìm kiếm nam sinh dựa vào ngày/tháng/năm
void timkiem_namsinh(vector<SINHVIEN> sv,wofstream &fileout) {
	wstring key; int flag = 0;
	vector <SINHVIEN> newsv;
	SINHVIEN s;
	wcout << L"Nhập năm sinh tìm kiếm:";
	wcin >> key;
	for (int i = 0; i < sv.size(); i++) {
		wstring nam = tach_nam(sv[i].date);
		if (nam.find(key) == 0) {
			Hien_thi(sv[i]);
			flag = 1;
		}
	}
	if (flag == 1) {
		for (int i = 0; i < sv.size(); i++) {
			wstring nam = tach_nam(sv[i].date);
			if (nam.find(key) != 0) {
				newsv.push_back(sv[i]);
			}
		}
		xoa(newsv, fileout);
	}
	else {
		wcout << L"Không tìm thấy sinh viên sinh năm " << key << endl;
		Sleep(4000);
		back();
	}
}
/*
câu 5
Tìm kiếm một sinh viên và trả về thông tin đầy đủ của sinh viên cũng như vị trí của sinh viên trong danh sách.
	Ví dụ: khi nhập vào MSSV thì trả về thông tin đầy đủ của sinh viên bao gồm họ và tên, MSSV, ngày tháng năm sinh,
	…. cũng như vị trí của sinh viên trong danh sách sinh viên
*/
// tìm kiếm theo masv
void timkiem_masv(vector<SINHVIEN> sv) {
	vector <SINHVIEN> mssv; int flag = 0;
	SINHVIEN s;
	int vitri = 0;

	wcout << L"Nhập MASV tìm kiếm :";
	wcin >> s.MASV;
	for (int i = 0; i < sv.size(); i++) {
		if (sv[i].MASV.find(s.MASV) == 0) {
			mssv.push_back(sv[i]);
			vitri = i;
			flag = 1;

		}
	}
	if (flag == 1) {
		for (int i = 0; i < mssv.size(); i++) {
			wcout << L"|" << setw(20) << L"MASV" << setw(5) << L"|" << setw(20) << L"HỌ VÀ TÊN" << setw(5) << L"|" << setw(15) << L"SỐ CMND" << setw(5) << L"|" << setw(15) << L"NGÀY SINH" << setw(5) << L"|" << setw(15) << L"QUÊ QUÁN" << setw(5) << L"|" << setw(20) << L"EMAIL" << setw(5) << L"|" << setw(20) << L"CHỔ HIỆN TẠI" << setw(10) << L"|" << endl;
			Hien_thi(mssv[i]);
		}
		wcout << L"Vị trí trong thứ :" << vitri << L" trong danh sách.\n";
	}
	else {
		wcout << L"Không tìm thấy sinh viên sinh có này. "<< endl;
		Sleep(2000);
		back();
	}
}
// câu 6  Cho phép merge 1 danh sách sinh viên mới với một danh sách sinh viên hiện có
// xóa phần tử trùng trong danh sách
void xoasvtrung(vector <SINHVIEN> &tam) {
	for (int j = 0; j < tam.size(); j++) {
	for (int i = j + 1; i < tam.size(); i++) {
		if (tam[i].MASV == tam[j].MASV) {
			tam.erase(tam.begin() + i);
		}
	}
}
}
void merge_moi_hienco(vector <SINHVIEN> ds_hienco, wifstream& file1, wifstream& file2,wofstream &file3) {
	vector <SINHVIEN> ds_moi;
	vector <SINHVIEN> tam;
	Doc_danh_sach_sinh_vien(file1, ds_hienco);
	Doc_danh_sach_sinh_vien(file2, ds_moi);
	for (int j = 1; j < ds_hienco.size()-1; j++) {
		tam.push_back(ds_hienco[j]);
	}
	for (int j = 1; j < ds_moi.size(); j++) {
		tam.push_back(ds_moi[j]);
	}
	xoasvtrung(tam);
	sapXepSV(tam, L"b");
	int xuat;
	wcout << L"Xuất file \n";
	wcout << L"\t1: xuất\n";
	wcout << L"\t0: hủy\n";
	wcout << L"Nhập lựa chọn :";
	wcin >> xuat;
	if (xuat == 1) {
		set_tieng_viet(file3);
		file3 << L"MASV" << L"," << L"HỌ VÀ TÊN" << L"," << L"SỐ CMND" << L"," << L"NGÀY SINH" << L"," << L"QUÊ QUÁN" << L"," << L"EMAIL" << L"," << L"CHỔ Ở HIỆN TẠI" << L"\n";
		for (int j = 1; j < tam.size(); j++) {
			
			ghi_vao_file(tam[j], file3);
		}
		wcout << L"Xuất file thành công.";
	}
	else {
		back();
	}
	file3.close();
}
// giao diện
void menu() {
	struct SINHVIEN sv;
	wifstream filein;
	wofstream fileout;
	wofstream fileout1;
	wifstream filein1;
	wifstream filein2;
	wofstream outdata;
	int chon;
	filein.open("sinhvien.csv", ios_base::in);
	filein1.open("sinhvienmoi.csv", ios_base::in);
	fileout.open("danhsachmoi.csv");
	//fileout.open(L"sinhvien.csv1");
	// khai bao danh sách sinh vien
	vector< SINHVIEN > ds_sv;
	//vector< SINHVIEN > ds_sv_tu_file_moi;
	//vector< SINHVIEN > ds_sv_tu_vector;
	int high = ds_sv.size();
	int low = 0;

	wcout << L"\t\t\t=========================THƯ MỤC =========================\n";
	wcout << L"\t\t\t|         1: Đọc file sinh viên có sẵn                    |\n";
	wcout << L"\t\t\t|         2: Merger sort                                  |\n";
	wcout << L"\t\t\t|       \ta: Sort theo ngày sinh                    |\n";
	wcout << L"\t\t\t|       \tb: Sort theo MASV                         |\n";
	wcout << L"\t\t\t|       \tc: Sort theo CMND                         |\n";
	wcout << L"\t\t\t|         3: Xóa Sinh viên                                |\n";
	wcout << L"\t\t\t|       \ta: Theo năm sinh                          |\n";
	wcout << L"\t\t\t|       \tb: Theo tên                               |\n";
	wcout << L"\t\t\t|       \te: Thoát                                  |\n";
	wcout << L"\t\t\t|         4: Tìm kiếm bằng MASV                           |\n";
	wcout << L"\t\t\t|         5: Merge danh sách mới với danh sách hiện có    |\n";
	wcout << L"\t\t\t==========================================================\n";
	wcout << endl << endl;
	Doc_danh_sach_sinh_vien(filein, ds_sv);
	
	wcout << L"Chon:"; wcin >> chon;
		if (chon > 0 && chon < 7) {
			switch (chon)
			{
			
			case 1:
			{
				Xuat_danh_sach_sinh_vien(ds_sv);
				wcout << L"Bấm Enter để quay lại màn hình chính.\n";
				_getch();
				back();

				break;
			}
			case 2:
			{
				wstring chon;
				wcout << L"Chọn kiểu sắp xếp :";
				wcin >> chon;
				sapXepSV(ds_sv,chon);
				wcout << L"Bạn muốn thêm sinh viên mới không ?\n";
				wcout << L"\t 1: Có.\n";
				wcout << L"\t 0: Trở lại màn hình chính.\n";
				int ch;
				wcout << L"Nhập sựa lựa chọn :";
				wcin >> ch;
				if (ch == 1) {
					Doc_danh_sach_sinh_vien(filein, ds_sv);
					themtheotieuchi(sv,chon,outdata,filein,ds_sv);
					wcout << L"Thêm thành công.\n";
					wcout << L"Bấm Enter để trở về giao diện chính.";
					_getch();
					back();
				}
				else {
					back();
				}
				break;
			}
			
			case 3:
			{
				Xuat_danh_sach_sinh_vien(ds_sv);
				wstring ch;
				wcout << L"Xóa sinh viên theo :"; wcin >> ch;
				if (ch == L"a" || ch == L"A") {
					timkiem_namsinh(ds_sv, fileout1);
				}
				if (ch == L"b" || ch == L"B") {
					timkiem_hoten(ds_sv, fileout1);
				}
				if (ch == L"e" || ch == L"E") {
					back();
				}
				break;
			}
			case 4:
			{
				timkiem_masv(ds_sv);
				wcout << L"Bấm Enter để trở về giao diện chính.";
				_getch();
				back();
				break;
			}
			case 5:
			{
				merge_moi_hienco(ds_sv, filein, filein1,fileout);
				break;
			}

			}
		}
		else {
			back();
		}
	filein.close();

}
void back() {
	system("cls");
	menu();
}
int wmain()
{
	_setmode(_fileno(stdin), _O_U16TEXT);// nhập vào tiếng việt
	_setmode(_fileno(stdout), _O_U16TEXT); // hiển thị trên màn hình tiếng việt
	SetConsoleTitleW(L"QUẢN LÝ SINH VIÊN");// set tiêu đề cho console là QUẢN LÝ SINH VIÊN
	HANDLE hdlConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_FONT_INFOEX consoleFont;
	consoleFont.cbSize = sizeof(consoleFont);
	GetCurrentConsoleFontEx(hdlConsole, FALSE, &consoleFont);
	memcpy(consoleFont.FaceName, L"Consolas", sizeof(consoleFont.FaceName));
	SetCurrentConsoleFontEx(hdlConsole, FALSE, &consoleFont);
	menu();
	_getch();
	return 0;
	
	
}